#!/usr/bin/env python
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages
setup(
  author="Maximilian Lange",
  author_email='maxhlange@gmail.com',
  classifiers=[
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3.9',
  ],
  description="This is a TEST",
  license="MIT license",
  include_package_data=True,
  name='mltestlib',
  version='0.1.0',
  zip_safe=False,
)
