def sayhello():
    print("Hi")